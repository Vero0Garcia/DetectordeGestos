import cv2


def condicionalesLetras(dedos, frame):
    font = cv2.FONT_HERSHEY_SIMPLEX

    # PRUEBA DE DEDOS

    #if dedos == [0, 0, 0, 0, 0, 1]:
     #   cv2.rectangle(frame, (0, 0), (100, 100), (255, 255, 255), -1)
      #  cv2.putText(frame, '0,0,0,0,0,1', (20, 80), font, 3, (0, 0, 0), 2, cv2.LINE_AA)
       # print("0,0,0,0,0,1")

    # FIN DE PRUEBA

    # A
    if dedos == [1, 1, 0, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'A', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("A")

    # B
    if dedos == [0, 0, 1, 1, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'B', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("B")

    # C
    if dedos == [1, 0, 1, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'C', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("C")

    # D
    if dedos == [0, 0, 0, 0, 0, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'D', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("D")

    # E
    if dedos == [0, 0, 0, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'E', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("E")

    # F
    if dedos == [1, 1, 1, 1, 1, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'F', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("F")

    # G


    # H


    # I
    if dedos == [0, 0, 1, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'I', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("I")

    # J (letra en movimiento)

    # K
    if dedos == [1, 1, 0, 0, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'K', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("K")

    # L
    if dedos == [1, 1, 0, 0, 0, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'L', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("L")

    # M


    # N
    if dedos == [0, 1, 0, 0, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'N', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("N")

    # O
    if dedos == [1, 0, 1, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'O', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("O")

    # P
    if dedos == [0, 1, 1, 1, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'P', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("P")

    # Q


    # R


    # S


    # T


    # U
    if dedos == [0, 0, 1, 0, 0, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'U', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("U")

    # V
    if dedos == [0, 1, 0, 0, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'V', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("V")

    # W
    if dedos == [0, 1, 0, 1, 1, 1]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'W', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("W")

    # X


    # Y
    if dedos == [1, 1, 1, 0, 0, 0]:
        cv2.rectangle(frame, (0, 0), (100, 100), (136, 138, 232), -1)
        cv2.putText(frame, 'Y', (20, 80), font, 3, (176, 212, 218), 6, cv2.LINE_AA)
        print("Y")

    # Z

    return dedos
